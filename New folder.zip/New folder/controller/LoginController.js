const database_conn = require("../Database/Database");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const MAX_ATTEMPTS = 5;
const LOCK_TIME = 15; // minutes

const Login = async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({
                error: "Email and password are required"
            });
        }

        // ── FIX 1: Added name to SELECT ──────────────────────────────
        // BEFORE: SELECT user_id, email, password, failed_login_attempts, account_locked_until
        // PROBLEM: user.name was undefined so response returned name: undefined
        // AFTER: Added name to the query so it's available in the response
        const result = await database_conn.query(
            `SELECT user_id, name, email, password,
                    failed_login_attempts,
                    account_locked_until
             FROM recipeusers
             WHERE lower(email) = lower($1)`,
            [email]
        );

        if (result.rowCount === 0) {
            return res.status(401).json({
                error: "Invalid email or password"
            });
        }

        const user = result.rows[0];

        // ── No changes here — account lock check is correct ──────────
        if (
            user.account_locked_until &&
            new Date(user.account_locked_until) > new Date()
        ) {
            const remainingTime = Math.ceil(
                (new Date(user.account_locked_until) - new Date()) / 60000
            );
            return res.status(403).json({
                error: `Account locked. Try again in ${remainingTime} minute(s).`
            });
        }

        const isMatch = await bcrypt.compare(password, user.password);

        if (!isMatch) {
            const attempts = (user.failed_login_attempts || 0) + 1;

            if (attempts >= MAX_ATTEMPTS) {

                // ── FIX 2: SQL injection fix on LOCK_TIME ────────────
                // BEFORE: `INTERVAL '${LOCK_TIME} minutes'`
                // PROBLEM: LOCK_TIME was directly interpolated into the SQL string
                //          if LOCK_TIME ever came from user input this would be
                //          a SQL injection vulnerability
                // AFTER: Using parameterized query $1 to safely pass the value
                await database_conn.query(
                    `UPDATE recipeusers
                     SET failed_login_attempts = 0,
                         account_locked_until = NOW() + ($1 || ' minutes')::INTERVAL
                     WHERE user_id = $2`,
                    [LOCK_TIME.toString(), user.user_id]
                );

                return res.status(403).json({
                    error: `Too many failed attempts. Account locked for ${LOCK_TIME} minutes.`
                });
            }

            await database_conn.query(
                `UPDATE recipeusers
                 SET failed_login_attempts = $1
                 WHERE user_id = $2`,
                [attempts, user.user_id]
            );

            return res.status(401).json({
                error: `Invalid email or password. Attempt ${attempts}/${MAX_ATTEMPTS}`
            });
        }

        // ── No changes here — reset attempts is correct ──────────────
        await database_conn.query(
            `UPDATE recipeusers
             SET failed_login_attempts = 0,
                 account_locked_until = NULL
             WHERE user_id = $1`,
            [user.user_id]
        );

        const token = jwt.sign(
            { user_id: user.user_id },
            process.env.JWT_SECRET,
            { expiresIn: "1d" }
        );

        // ── FIX 3: sameSite cookie fix ───────────────────────────────
        // BEFORE: sameSite: "none" always
        // PROBLEM: sameSite "none" requires secure: true to work
        //          on localhost secure is false so cookie was being
        //          rejected by the browser and never stored
        // AFTER: sameSite is "lax" in development and "none" in production
        //        this way cookie works locally AND in production
        res.cookie("token", token, {
            httpOnly: true,
            secure: process.env.NODE_ENV === "production",
            sameSite: process.env.NODE_ENV === "production" ? "none" : "lax",
            maxAge: 24 * 60 * 60 * 1000
        });

        // ── FIX 1 result: name is now available here ─────────────────
        // user.name was undefined before because it wasnt in the SELECT
        // now it returns correctly to the frontend
        // Frontend accesses it as: data.user.name
        return res.status(200).json({
            message: "Login successful",
            token: token,   // remove in production
            user: {
                user_id: user.user_id,
                name:    user.name,     // ✅ now works — was undefined before
                email:   user.email,
            }
        });

    } catch (err) {
        console.log(err);
        return res.status(500).json({
            error: "Internal server error"
        });
    }
};

module.exports = Login;