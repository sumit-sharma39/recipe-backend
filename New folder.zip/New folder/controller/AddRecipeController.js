const fs   = require("fs");
const path = require("path");

// ── Path to your JSON file ───────────────────────────────────────────
const recipesPath = path.join(__dirname, "../recipes.json");

const AddRecipe = async (req, res) => {
    try {

        const {
            title,
            description,
            category,
            time,
            servings,
            difficulty,
            image,
            ingredients,
            steps,
        } = req.body;

        // ── Validate required fields ─────────────────────────────────
        if (!title || !time || !category) {
            return res.status(400).json({
                error: "Title, time and category are required"
            });
        }

        // ── Read current JSON file ───────────────────────────────────
        const raw     = fs.readFileSync(recipesPath, "utf-8");
        const recipes = JSON.parse(raw);

        const maxId  = recipes.reduce((max, r) => Math.max(max, Number(r._id) || 0), 0);
        const newId  = String(maxId + 1);

        // ── Build new recipe object ──────────────────────────────────
        const newRecipe = {
            _id:         newId,
            title:       title.trim(),
            description: description?.trim() || "",
            category,
            time:        Number(time),
            servings:    Number(servings) || 2,
            difficulty:  difficulty || "Easy",
            image:       image || "🍽️",
            ingredients: Array.isArray(ingredients)
                            ? ingredients          // already array from frontend
                            : ingredients.split("\n").filter(Boolean), // fallback
            steps:       Array.isArray(steps)
                            ? steps
                            : steps.split("\n").filter(Boolean),
            rating:      0,
            createdAt:   new Date().toISOString(),
        };

        // ── Add to beginning of array (newest first) ─────────────────
        recipes.unshift(newRecipe);

        // ── Write back to JSON file ──────────────────────────────────
        fs.writeFileSync(recipesPath, JSON.stringify(recipes, null, 4), "utf-8");


        return res.status(201).json(newRecipe);

    } catch (err) {
        console.error("AddRecipe error:", err.message);
        return res.status(500).json({ error: "Internal server error" });
    }
};

module.exports = AddRecipe;