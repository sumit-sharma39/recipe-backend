const fs   = require("fs");
const path = require("path");

// ── Load JSON file once when server starts ──────────────────────────
const recipesPath = path.join(__dirname, "../recipes.json");
const recipes     = JSON.parse(fs.readFileSync(recipesPath, "utf-8"));

const GetAllRecipes = async (req, res) => {
    try {

        const { category, search } = req.query;

        // ── Start with all recipes ──────────────────────────────────
        let result = [...recipes];

        // ── Filter by category if provided ──────────────────────────
        // ?category=Pasta  →  only Pasta recipes
        // ?category=All    →  skip filter, return all
        if (category && category !== "All") {
            result = result.filter(
                (r) => r.category === category
            );
        }

        // ── Filter by search if provided ────────────────────────────
        // ?search=chicken  →  only recipes with "chicken" in title
        if (search && search.trim() !== "") {
            result = result.filter((r) =>
                r.title.toLowerCase().includes(search.toLowerCase().trim())
            );
        }

        // ── Sort newest first using _id ─────────────────────────────
        // Higher _id = added later = show first
        result = result.sort((a, b) => Number(b._id) - Number(a._id));

        // ── Return plain array ──────────────────────────────────────
        // Frontend does: const { data } = await api.get("/recipes")
        // then: setRecipes(data)
        // so data MUST be a plain array, not wrapped in an object
        return res.status(200).json(result);

    } catch (err) {
        console.error("GetAllRecipes error:", err.message);
        return res.status(500).json({ error: "Internal server error" });
    }
};

module.exports = GetAllRecipes;