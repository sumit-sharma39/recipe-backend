const Database_conn = require("../Database/Database");
const bcrypt = require('bcrypt');
const jwt = require("jsonwebtoken");

const Register = async (req, res) => {
    try {
        const {name ,  username, email, password } = req.body;

        if (!name || !username || !email || !password) {
            return res.status(400).json({
                error: "Username, email and password are required"
            });
        }

        const validatePassword = (password) => {
            const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+]).{8,25}$/;
            return regex.test(password);
        };

        if (!validatePassword(password)) {
            return res.status(400).json({
                error: "Password must be 8–25 characters and include uppercase, lowercase, number and special character"
            });
        }

        const check = await Database_conn.query(
            "SELECT user_id FROM recipeusers WHERE lower(email) = lower($1)",
            [email]
        );

        if (check.rowCount > 0) {
            return res.status(409).json({
                error: "User already exists. Please login."
            });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const result = await Database_conn.query(
            `INSERT INTO recipeusers (name ,username, email, password)
             VALUES ($1, $2, $3 , $4)
             RETURNING user_id, email, username,name`,
            [ name , username, email, hashedPassword]
        );

        const newUser = result.rows[0];

        const token = jwt.sign(
            {
                user_id: newUser.user_id,
                email: newUser.email
            },
            process.env.JWT_SECRET,
            { expiresIn: "1d" }
        );

        res.cookie("token", token, {
            httpOnly: true,
            secure: process.env.NODE_ENV === "production",
            sameSite: process.env.NODE_ENV === "production" ? "none" : "lax",
            maxAge: 24 * 60 * 60 * 1000
        });

        return res.status(201).json({
            message: "Registration successful",
            token: token,           // ← added
            user: {
                user_id: newUser.user_id,
                email:   newUser.email,
                username:    newUser.username,
                name: newUser.name
            }
        });

    } catch(error) {
        console.error("Register error:", error);
        return res.status(500).json({ message: "Something went wrong" });
    }
};

module.exports = Register;