const express = require('express')
const router = express.Router();

const FetchRecipes= require("../controller/FetchRecipesController");

const auth =require("../middleware/auth");
router.get("/", FetchRecipes);

module.exports = router;