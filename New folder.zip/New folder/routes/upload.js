import express from "express";
import { upload } from "../middleware/cloudinary.js";

const router = express.Router();

router.post("/upload", upload.single("file"), (req, res) => {
    try {
        res.status(200).json({ url: req.file.path });
    } catch (err) {
        res.status(500).json({ message: "Image upload failed" });
    }
});

export default router;