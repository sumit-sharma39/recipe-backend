const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');
require('dotenv').config();

const AuthRoutes = require("./routes/Authroute");     // ✅ fix path
const AuthRecipes=require("./routes/AuthRecipes")
const upload= require("./routes/upload");


const app = express();

app.use(cors({
    origin: "http://localhost:5173",
    credentials: true,
}));

app.use(express.json());    // ✅ use, not search
app.use(cookieParser());

app.use('/api/auth', AuthRoutes);
app.use('/api/recipes', AuthRecipes);
app.use("/upload", uploadRouter);


app.use((req, res) => {
    res.status(404).json({ message: "Route was not found" }); 
});

const PORT = process.env.SERVER_PORT || 8000;
app.listen(PORT, () => {
    console.log(`Server started at port ${PORT}`);
});