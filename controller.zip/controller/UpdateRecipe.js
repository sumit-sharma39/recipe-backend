const fs   = require("fs");
const path = require("path");
const recipesPath = path.join(__dirname, "../recipes.json");

const UpdateRecipe = async (req, res) => {
  try {
    const recipes = JSON.parse(fs.readFileSync(recipesPath, "utf-8"));
    const index   = recipes.findIndex((r) => r._id === req.params.id);
    if (index === -1) return res.status(404).json({ message: "Recipe not found" });
    if (recipes[index].authorId !== req.user.id)
      return res.status(403).json({ message: "Not authorized" });

    recipes[index] = { ...recipes[index], ...req.body, _id: req.params.id };
    fs.writeFileSync(recipesPath, JSON.stringify(recipes, null, 4), "utf-8");
    return res.status(200).json(recipes[index]);
  } catch (err) {
    return res.status(500).json({ error: "Internal server error" });
  }
};

module.exports = UpdateRecipe;