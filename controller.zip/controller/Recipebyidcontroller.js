const fs   = require("fs");
const path = require("path");
const recipesPath = path.join(__dirname, "../recipes.json");

const GetRecipeById = async (req, res) => {
  try {
    const recipes = JSON.parse(fs.readFileSync(recipesPath, "utf-8"));
    const recipe  = recipes.find((r) => r._id === req.params.id);
    if (!recipe) return res.status(404).json({ message: "Recipe not found" });
    return res.status(200).json(recipe);
  } catch (err) {
    return res.status(500).json({ error: "Internal server error" });
  }
};

module.exports = GetRecipeById;