const fs   = require("fs");
const path = require("path");
const recipesPath = path.join(__dirname, "../recipes.json");

const DeleteRecipe = async (req, res) => {
  try {
    let recipes  = JSON.parse(fs.readFileSync(recipesPath, "utf-8"));
    const recipe = recipes.find((r) => r._id === req.params.id);
    if (!recipe) return res.status(404).json({ message: "Recipe not found" });
    if (recipe.authorId !== req.user.id)
      return res.status(403).json({ message: "Not authorized" });

    recipes = recipes.filter((r) => r._id !== req.params.id);
    fs.writeFileSync(recipesPath, JSON.stringify(recipes, null, 4), "utf-8");
    return res.status(200).json({ message: "Recipe deleted" });
  } catch (err) {
    return res.status(500).json({ error: "Internal server error" });
  }
};

module.exports = DeleteRecipe;